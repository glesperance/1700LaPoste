<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-yaml?lang_cible=ru
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// Y
	'yaml_description' => 'Плагин позволяет использовать функции чтения/записи в формате YAML:
	<code>yaml_decode()</code> и <code>yaml_encode()</code>. И позволяет использовать YAML в запросе BOUCLE(DATA).',
	'yaml_slogan' => 'Позволяет работать с YAML форматом'
);

?>
