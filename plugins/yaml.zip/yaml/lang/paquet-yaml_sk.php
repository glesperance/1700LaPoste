<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-yaml?lang_cible=sk
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// Y
	'yaml_description' => 'Tento zásuvný modul ponúka funkcie čítanie/zápisu formátu YAML:
	<code>yaml_decode()</code> a <code>yaml_encode()</code>. Poskytuje formát yaml aj pre cyklus (DATA).',
	'yaml_slogan' => 'Jednoduchý formát súborov na upravovanie zoznamov dát'
);

?>
