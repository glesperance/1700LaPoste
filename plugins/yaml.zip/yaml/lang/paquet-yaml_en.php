<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-yaml?lang_cible=en
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// Y
	'yaml_description' => 'This plugin provides the functions for reading/writing YAML format:
<code>yaml_decode()</code> and <code>yaml_encode()</code>. It also provides the yaml format for the (DATA) loop.',
	'yaml_slogan' => 'A simple file format for editing lists of data'
);

?>
