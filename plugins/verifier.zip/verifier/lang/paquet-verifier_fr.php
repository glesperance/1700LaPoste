<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// Fichier source, a modifier dans svn://zone.spip.org/spip-zone/_plugins_/verifier/lang/
if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// V
	'verifier_description' => 'Fournit une fonction unique <code>verifier($valeur, $type, $options, &$valeur_normalisee)</code> permettant de tester la validité d’une valeur.',
	'verifier_nom' => 'API de vérification',
	'verifier_slogan' => 'Une API générique pour vérifier une valeur'
);

?>
