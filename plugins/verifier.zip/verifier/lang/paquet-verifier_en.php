<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-verifier?lang_cible=en
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// V
	'verifier_description' => 'Provides a unique function <code>verifier($value, $type, $options,&$valeur_normalisee)</code> to test the validity of a value.',
	'verifier_nom' => 'Control API',
	'verifier_slogan' => 'A generic API to control a value'
);

?>
