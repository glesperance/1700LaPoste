<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-verifier?lang_cible=sk
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// V
	'verifier_description' => 'Poskytuje jedinečnú funkciu <code>verifier($hodnota, $typ, $podmienky),</code> ktorá umožňuje otestovať platnosť hodnoty.',
	'verifier_nom' => 'Aplikácia na overenie',
	'verifier_slogan' => 'Spoločná aplikácia na overenie hodnoty'
);

?>
