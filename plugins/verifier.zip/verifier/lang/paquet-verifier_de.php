<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-verifier?lang_cible=de
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// V
	'verifier_description' => 'Stellt die Funktion<code>verifier($wert, $typ, $optionen, $normalisierter_wert)</code>bereit, mit der ein Werts auf Gültigkeit geprüft werden kann.',
	'verifier_nom' => 'API Wertprüfung',
	'verifier_slogan' => 'API zur Prüfung von Werten'
);

?>
