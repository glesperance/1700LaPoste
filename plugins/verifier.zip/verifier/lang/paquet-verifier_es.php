<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-verifier?lang_cible=es
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// V
	'verifier_description' => 'Proporciona una función única <code>verifier($valeur, $type, $options, &$valeur_normalisee)</code> para probar la validez de un valor',
	'verifier_nom' => 'API de verificación',
	'verifier_slogan' => 'Una API genérica para verificar un valor'
);

?>
