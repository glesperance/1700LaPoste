<?php

// pour compter_champs_extras
include_spip('inc/iextras');

?>
