<?php

// pour extras_champs_utilisables()
include_spip('inc/cextras');

?>
