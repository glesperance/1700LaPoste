<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-iextras?lang_cible=en
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// I
	'iextras_description' => 'Adds in the private space a complete interface to manage additional fields on editorial objects.',
	'iextras_nom' => 'Extra fields (Interface)',
	'iextras_slogan' => 'Interface to manage the extra fields on SPIP objects',
	'iextras_titre' => 'Extra fields (Interface)'
);

?>
