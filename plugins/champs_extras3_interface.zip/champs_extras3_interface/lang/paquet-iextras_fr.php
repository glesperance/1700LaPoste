<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// Fichier source, a modifier dans svn://zone.spip.org/spip-zone/_plugins_/champs_extras/interface/trunk/lang/
if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// I
	'iextras_description' => 'Ajoute dans l’espace privé une interface complète de gestion de champs supplémentaires
							dans les objets éditoriaux.',
	'iextras_nom' => 'Champs Extras (Interface)',
	'iextras_slogan' => 'Offre une interface graphique pour gérer des champs extras',
	'iextras_titre' => 'Champs Extras (Interface)'
);

?>
