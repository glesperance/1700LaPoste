<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-iextras?lang_cible=sk
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// I
	'iextras_description' => 'Do súkromnej zóny pridá kompletné rozhranie na riadenie doplnkových polí
							v redakčných objektoch.',
	'iextras_nom' => 'Ďalšie polia (rozhranie)',
	'iextras_slogan' => 'Ponúka grafické rozhranie na riadenie ďalších polí',
	'iextras_titre' => 'Ďalšie polia (rozhranie)'
);

?>
