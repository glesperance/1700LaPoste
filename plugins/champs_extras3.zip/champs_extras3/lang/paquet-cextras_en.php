<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-cextras?lang_cible=en
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// C
	'cextras_description' => 'Provides a simple API to create new fields on the editorial objects.
It is the base for other plugins including "Extras Fields Interface" which provides
a graphical interface to manage these new fields.',
	'cextras_nom' => 'Extra fields',
	'cextras_slogan' => 'Create new edit fields for SPIP objects',
	'cextras_titre' => 'Extra fields'
);

?>
