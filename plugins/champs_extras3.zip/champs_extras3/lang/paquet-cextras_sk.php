<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-cextras?lang_cible=sk
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// C
	'cextras_description' => 'Ponúka jednoduchú aplikáciu, ktorá umožňuje vytvárať nové polia v redakčných objektoch.
					Je základom pre iné zásuvné moduly, vrátane  "Rozhrania doplnkových polí", ktoré poskytuje
					grafické rozhranie na riadenie týchto nových polí.',
	'cextras_nom' => 'Doplnkové polia',
	'cextras_slogan' => 'Aplikácia na riadenie nových polí v redakčných objektoch',
	'cextras_titre' => 'Doplnkové polia'
);

?>
