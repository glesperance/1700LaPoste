<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// Fichier source, a modifier dans svn://zone.spip.org/spip-zone/_plugins_/champs_extras/core/trunk/lang/
if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// C
	'cextra_par_defaut' => 'Valeur par défaut',

	// P
	'pas_auteur' => 'pas d’auteur',

	// T
	'type' => '@type@',

	// Z
	'zbug_balise_argument_non_texte' => 'L’argument @nb@ dans la balise @balise@ doit être de type texte'
);

?>
