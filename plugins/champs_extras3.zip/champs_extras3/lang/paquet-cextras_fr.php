<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// Fichier source, a modifier dans svn://zone.spip.org/spip-zone/_plugins_/champs_extras/core/trunk/lang/
if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// C
	'cextras_description' => 'Offre une API simple permettant de créer de nouveaux champs dans les objets éditoriaux.
					Il est donc le socle pour d’autres plugins notamment pour « Champs Extras Interface » qui donne
					une interface graphique de gestion de ces nouveaux champs.',
	'cextras_nom' => 'Champs Extras',
	'cextras_slogan' => 'API de gestion de nouveaux champs dans les objets éditoriaux.',
	'cextras_titre' => 'Champs Extras'
);

?>
