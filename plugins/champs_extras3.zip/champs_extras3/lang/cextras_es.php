<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/cextras?lang_cible=es
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// C
	'cextra_par_defaut' => 'Valor por defecto',

	// P
	'pas_auteur' => 'sin autor',

	// T
	'type' => '@type@',

	// Z
	'zbug_balise_argument_non_texte' => 'El argumento @nb@ de la etiqueta @balise@ debe ser de tipo texto'
);

?>
