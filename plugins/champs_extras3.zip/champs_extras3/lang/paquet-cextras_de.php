<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-cextras?lang_cible=de
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// C
	'cextras_nom' => 'Zusatzfelder',
	'cextras_slogan' => 'Zusätzliche Felder für die Standardobjekte von SPIP anlegen',
	'cextras_titre' => 'Zusatzfelder'
);

?>
