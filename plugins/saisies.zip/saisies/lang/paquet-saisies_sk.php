<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-saisies?lang_cible=sk
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// S
	'saisies_description' => 'Tento zásuvný modul uľahčuje zápis polí formulára ponúknutím tagu #INPUT. Vytvorený kód HTML je kompatibilný s klasifikáciou formulárov, ktorú ponúka SPIP > 2.0 a so zásuvným modulom na konfiguráciu – CFG.',
	'saisies_nom' => 'Vstupy pre formuláre',
	'saisies_slogan' => 'Jednoduchý zápis polí formulárov.',
	'saisies_titre' => 'Vstupy pre formuláre'
);

?>
