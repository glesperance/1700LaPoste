<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-saisies?lang_cible=de
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// S
	'saisies_description' => 'Dieses Plugin erleichtert die Erstellung von Eingabefeldern für Formulare und bietet einen Tag #SAISIE. Das erzeugte HTML ist mit der Nomenklatur der von SPIP > 2.0 und dem Plugin CFG kompatibel.',
	'saisies_nom' => 'Eingabefelder für Formulare',
	'saisies_slogan' => 'Unkompliziertes Erstellen von Eingabefeldern für Formulare.',
	'saisies_titre' => 'Eingabefelder für Formulare'
);

?>
