<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-saisies?lang_cible=ru
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// S
	'saisies_description' => 'Этот плагин облегчает работу по созданию форм. Вам предоставляется возможность создавать поля (input,textarea) в форме при помощи тега #SAISIE. Полученная форма полностью совместима со стандартом  SPIP 2.0+ и c плагином CFG.',
	'saisies_nom' => 'Поля для форм (saises)',
	'saisies_slogan' => 'Упрощение работы по созданию форм',
	'saisies_titre' => 'Поля для форм (saises)'
);

?>
