<?php
$GLOBALS[$GLOBALS['idx_lang']] = array(

	'fabrique_titre' => 'Fabrique',
	'fabrique_slogan' => 'Outil pour créer des plugins SPIP.',
	'fabrique_description' => 'Ce plugin permet de générer le code de plugins pour SPIP.
		Il peut gérer la création d\'objets éditoriaux simples. L\'objectif n\'est pas de faire créer un
		plugin parfait, mais une base solide, rapide à mettre en place, à éditer ensuite à votre goût.',
);
?>
